#include <stdio.h>
#include <stdlib.h>
#include "SVGParser.h"
#include "LinkedListAPI.h"

/*  <LL helper functions>   */
void deleteAttribute( void* data);
char* attributeToString( void* data);
int compareAttributes(const void *first, const void *second);

void deleteGroup(void* data);
char* groupToString( void* data);
int compareGroups(const void *first, const void *second);

void deleteRectangle(void* data);
char* rectangleToString(void* data);
int compareRectangles(const void *first, const void *second);

void deleteCircle(void* data);
char* circleToString(void* data);
int compareCircles(const void *first, const void *second);

void deletePath(void* data);
char* pathToString(void* data);
int comparePaths(const void *first, const void *second);

void universalNoDelete(void *data);
/*  </LL helper functions>   */

List* getPaths(SVGimage* img);

int main(void) {
    int svgElement;
    SVGimage *image;
    char *string;
    List *list;
    int a;

    //printf("val (0->6): ");
    //scanf("%d", &svgElement);
    for (int i = 0; i < 6; i++) {
        printf("*** Test: %d ***\n", i);

        if (i == 0 ) {
            image = createSVGimage("rect.svg");

        } else if (i == 1 ) {
            image = createSVGimage("rec_with_units.svg");

        } else if (i == 2 ) {
            image = createSVGimage("quad01.svg");

        } else if (i == 3 ) {
            image = createSVGimage("rects.svg");

        } else if (i == 4 ) {
            image = createSVGimage("Emoji_poo.svg");

        }  else if (i == 5 ) {
            image = createSVGimage("Emoji_shades.svg");

        } else {
            image = createSVGimage("Emoji_smiling.svg");
        }

        printf("SVGimageToString\n");
        string = SVGimageToString(image);
        free(string);

        //rects
        printf("Create Rectangle List\n");
        list = getRects(image);
        string = toString(list);
        free(string);
        freeList(list);

        //circles
        printf("Create Circle List\n");
        list = getCircles(image);
        string = toString(list);
        free(string);
        freeList(list);

        //paths
        printf("Create Paths List\n");
        list = getPaths(image);
        string = toString(list);
        free(string);
        freeList(list);

        //groups
        printf("Create groups List\n");
        list = getGroups(image);
        string = toString(list);
        free(string);
        freeList(list);

        a = numRectsWithArea(image, 0);
        a = numCirclesWithArea(image, 0);
        a = numPathsWithdata(image, "Data");
        a = numGroupsWithLen(image, 0);

        a = numAttr(image);
        
        deleteSVGimage(image);
    }

    

    return 0;
}