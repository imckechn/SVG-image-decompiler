#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include <libxml/parser.h>
#include <libxml/tree.h>
#include <libxml/encoding.h>
#include <libxml/xmlwriter.h>
#include <libxml/xmlschemastypes.h>
#include <math.h>

#include "LinkedListAPI.h"
#include "SVGParser.h"

#define  NUMFLOATINGPOINTS 10

/*      Random helper functions that don't have a specific category     */
xmlDocPtr populateXmlDocPtr(char *fileName);
SVGimage* xmlDocToSvgDoc(xmlDoc *xmlDoc);
void getXmlInformation(xmlNode *root, SVGimage *image);
Group* generateGroup( xmlNode *root );
void groupGetXmlInformation(xmlNode *newRoot, Group *g);
int getSizeOfGroup(Group *gsub);
char* unitCheck(char *content);

/*  <Getting a list of every specific shape/element from a group tree>   */
void getRectsFromGroup(Group *g, List *newRectList);
void getCirclesFromGroup(Group *g, List *newCircleList);
void getGroupsFromGroup(Group *g, List *newGroupList);
int getGroupsFromParentGroup(Group *g, int len);
void getPathsFromGroup(Group *g, List *newPathList);
/*  </Getting a list of every specific shape/element from a group tree>   */

/*  <LL helper functions>   */
void deleteAttribute( void* data);
char* attributeToString( void* data);
int compareAttributes(const void *first, const void *second);

void deleteGroup(void* data);
char* groupToString( void* data);
int compareGroups(const void *first, const void *second);

void deleteRectangle(void* data);
char* rectangleToString(void* data);
int compareRectangles(const void *first, const void *second);

void deleteCircle(void* data);
char* circleToString(void* data);
int compareCircles(const void *first, const void *second);

void deletePath(void* data);
char* pathToString(void* data);
int comparePaths(const void *first, const void *second);

void universalNoDelete(void *data);
/*  </LL helper functions>   */

/*  <Struct pointer initialization functions>   */
SVGimage* initializeSvgImage();
Group* initializeGroup();
Rectangle* initializeRectangle();
Circle* initializeCircle();
Path* initializePath(char *data);
Attribute* initializeAttribute(char *name, char *value);
/*  </Struct pointer initialization functions>   */

/*  <Helper functions for 'numAtter'>   */
int getAttributeCountFromRectangleList(List *rectangleList);
int getAttributeCountFromCircleList(List *circleList);
int getAttributeCountFromPathList(List *pathList);
int getAttributeCountFromGroupList(List *groupsList);
int getAttributesFromGroupAndItsShapes(Group *group);
/*  </Helper functions for 'numAtter'>   */

/*  This is the main function. Calls all the helper functions so it can take an SVG file name and return all the SVG elements and
*   information back to the user.
*   @Param  The filename of the image.
*   @return The SVG information in a struct.
*/
SVGimage* createSVGimage(char* fileName) {

    if (fileName == NULL) return NULL;

    SVGimage* image;
    xmlDoc *doc = NULL;

    doc = xmlReadFile(fileName, NULL, 0);

    if (doc == NULL) {
        xmlFreeDoc(doc);
        return NULL;
    }

    //Now get the SVG content from the XML doc
    image = xmlDocToSvgDoc(doc);

    xmlFreeDoc(doc);
    //xmlFreeParserCtxt(ctxt);
    xmlCleanupParser();

    return image;
}

/*
Used "parser.c" by Daniel Veillard as reference.
This reference was found on http://www.xmlsoft.org

This turns an XML doc (what SVG is based on) into a XML fill structure based on libxml2
*/
xmlDocPtr populateXmlDocPtr(char *fileName) {

    xmlParserCtxtPtr ctxt; /* the parser context */
    xmlDocPtr doc; /* The tree root */

    if (fileName == NULL) {
        return NULL;
    }

    //This makes an XML doc from the given file, otherwise returns null.
    ctxt = xmlNewParserCtxt();
    if (ctxt == NULL) {
	    return NULL;
    }
    doc = xmlCtxtReadFile(ctxt, fileName, NULL, XML_PARSE_DTDVALID);
    if (doc == NULL) {

        return NULL;
    } else {
        if (ctxt->valid == 0) {
            return NULL;
            //Could not validate
        }
	        
    }

    //On success
    return doc;
}

/*  This is another function handler function. Calls all the Functions that actually turn the XML information into SVG information.
*   @Param  the XML doc
*   @return the full SVG file full of the info from the xml file.
*/
SVGimage * xmlDocToSvgDoc(xmlDoc *doc) {

    SVGimage *image = initializeSvgImage(1);   //**** THis has to be fixed

    xmlNode *root = xmlDocGetRootElement(doc);
    getXmlInformation(root, image);
    
    return image;
}

/*
This loop structure was from tree.c 
http://www.xmlsoft.org/examples/tree2.c
Written by Lucas Brasilino
*   This loops through the XML tree and disects it looking for SVG elements and the information about them.
*   @Param  the root xml Node, the SVG image that will be returned.
*/
void getXmlInformation(xmlNode *root, SVGimage *image) {

    xmlNode *cur_node = NULL;

    if ( strcmp(image->namespace, "") == 0) {
        for (cur_node = root; cur_node; cur_node = cur_node->next) {
            if (cur_node->type == XML_ELEMENT_NODE) {   //This gets all the XML nodes recursivly 
                strcpy(image->namespace, (char *) cur_node->ns->href);
                goto ENDLOOP;
            }
        }
    }
    ENDLOOP:        //Goto, only good case for it.


    for (cur_node = root; cur_node; cur_node = cur_node->next) {
        if (cur_node->type == XML_ELEMENT_NODE) {   //This gets all the XML nodes recursivly 
            
            if ( strcmp( (char *) cur_node->name, "g") == 0 ) {     //If a group tag is encountered
                Group *g = generateGroup(cur_node);

                insertBack(image->groups, g);
                cur_node = cur_node->next; 
                continue;
            }

            if (cur_node->children != NULL) {   //Get TITLE and DESC if they haven't been collected already

                if ( (strcmp( (char *) cur_node->name, "title") == 0)  &&  ( strcmp(image->title, "") == 0) )
                {                
                    if ( (cur_node->children)->content != NULL) {
                        strcpy(image->title, (char *) (cur_node->children)->content );
                    }

                } else if ( (strcmp( (char *) cur_node->name, "desc") == 0)  &&  ( strcmp(image->description, "") == 0) ) {
                    if ( (cur_node->children)->content != NULL) {
                        strcpy(image->description, (char *) (cur_node->children)->content );
                    }
                }                    
            } 

            if (cur_node->properties != NULL) {     //This gets the attibutes. All of them.
                xmlAttr *attribute = cur_node->properties;

                //If the element is a rectangle, circle, or path, it will initialize it, populate it with its attributes and add it to the SVG element
                if ( strcmp( (char *) cur_node->name, "rect") == 0 ) { 

                    Rectangle *rect = initializeRectangle();
                    
                    do {

                        strcpy(rect->units, unitCheck((char *) attribute->children->content));

                        if ( strcmp( (char *) attribute->name, "x") == 0 ) {
                            rect->x = atof( (char *) attribute->children->content);

                        } else if ( strcmp( (char *) attribute->name, "y") == 0 ) {
                            rect->y = atof( (char *) attribute->children->content);

                        } else if ( strcmp( (char *) attribute->name, "width") == 0 ) {
                            rect->width = atof( (char *) attribute->children->content);

                        } else if ( strcmp( (char *) attribute->name, "height") == 0 ) {
                            rect->height = atof( (char *) attribute->children->content);
                        
                        } else {
                            Attribute *atty = initializeAttribute((char *) attribute->name, (char *) attribute->children->content);
                            insertBack( rect->otherAttributes, atty);
                        }
                    
                    } while ( (attribute = attribute->next) ); 

                    insertBack(image->rectangles, rect);

                } else if ( strcmp( (char *) cur_node->name, "circle") == 0 ) { 
                    
                    Circle *circle = initializeCircle();
                    
                    do {
                        strcpy(circle->units, unitCheck((char *) attribute->children->content));

                        if ( strcmp( (char *) attribute->name, "cx") == 0 ) {
                            circle->cx = atof( (char *) attribute->children->content);

                        } else if ( strcmp( (char *) attribute->name, "cy") == 0 ) {
                            circle->cy = atof( (char *) attribute->children->content);

                        } else if ( strcmp( (char *) attribute->name, "r") == 0 ) {
                            circle->r = atof( (char *) attribute->children->content);

                        } else {
                            Attribute *atty = initializeAttribute((char *) attribute->name, (char *) (attribute->children)->content);

                            insertBack( circle->otherAttributes, atty);
                        }
                    
                    } while ( (attribute = attribute->next) );  
                    
                    insertBack(image->circles, circle);


                } else if ( strcmp( (char *) cur_node->name, "path") == 0 ) {

                    Path *path;

                    do {    //Need to loop once first to get the data attribute first. 

                        if ( strcmp( (char *) attribute->name, "d") == 0 ) {
                            path = initializePath( (char *) attribute->children->content);
                        }
                    
                    } while ( path == NULL);

                    attribute = cur_node->properties;
                    
                    do {    //Loop again, collecting all none data attributes as 'otherAttributes' 

                        if ( strcmp( (char *) attribute->name, "d") == 0 ) {
                            continue;

                        } else {
                            Attribute *atty = initializeAttribute((char *) attribute->name, (char *) (attribute->children)->content);

                            insertBack( path->otherAttributes, atty);
                        }
                    
                    } while ( (attribute = attribute->next) ); 

                    insertBack(image->paths, path);
                } else if ( strcmp( (char *) cur_node->name, "svg") == 0 ) {
                    
                    do {    //Loop again, collecting all none data attributes as 'otherAttributes' 

                        Attribute *atty = initializeAttribute((char *) attribute->name, (char *) (attribute->children)->content);
                        insertBack( image->otherAttributes, atty);
                    
                    } while ( (attribute = attribute->next) ); 
                }
                
            }
        }

        getXmlInformation(cur_node->children, image);
    }
}


/*  When a group is encountered, it calls this loop so you can add found elements to a group instead of the SVG element.
*   @Param  The the root xmlNode from the xml tree.
*   @Return an alloced and filled group element.
*/
Group* generateGroup( xmlNode *root ) {
    Group *g = initializeGroup();

    //Gets the group node im currently on's attributes
    if (root->properties != NULL) {     //This gets the attibutes. All of them.
        xmlAttr *attribute = root->properties;
            
        do {

            Attribute *atty = initializeAttribute((char *) attribute->name, (char *) (attribute->children)->content);
            insertBack( g->otherAttributes, atty);
        
        } while ( (attribute = attribute->next) );             
    } 
        
    xmlNode *cur_node;
    root = root->children;

    //Collects all of the groups children and their informaton.
    for (cur_node = root->next; cur_node; cur_node = cur_node->next) {
        if (cur_node->type == XML_ELEMENT_NODE) {   //This gets all the XML nodes recursivly 
            
            if ( strcmp( (char *) cur_node->name, "g") == 0 ) { //If a group tag is encountered
                Group *g2 = generateGroup(cur_node);

                insertBack(g->groups, g2); 
                continue;
            }

            if (cur_node->properties != NULL) {     //This gets the attibutes. All of them. (Even the woman and children attributes. They're animals, all of them)
                xmlAttr *attribute = cur_node->properties;

                //If the element is a rectangle, circle, or path, it will initialize it, populate it with its attributes and add it to the SVG element
                if ( strcmp( (char *) cur_node->name, "rect") == 0 ) { 

                    Rectangle *rect = initializeRectangle();
                                        
                    do {
                        strcpy(rect->units, unitCheck((char *) attribute->children->content));

                        if ( strcmp( (char *) attribute->name, "x") == 0 ) {
                            rect->x = atof( (char *) attribute->children->content);

                        } else if ( strcmp( (char *) attribute->name, "y") == 0 ) {
                            rect->y = atof( (char *) attribute->children->content);

                        } else if ( strcmp( (char *) attribute->name, "width") == 0 ) {
                            rect->width = atof( (char *) attribute->children->content);

                        } else if ( strcmp( (char *) attribute->name, "height") == 0 ) {
                            rect->height = atof( (char *) attribute->children->content);

                        } else {
                            Attribute *atty = initializeAttribute((char *) attribute->name, (char *) (attribute->children)->content);

                            insertBack( rect->otherAttributes, atty);
                        }
                    
                    } while ( (attribute = attribute->next )); 

                    insertBack(g->rectangles, rect);

                } else if ( strcmp( (char *) cur_node->name, "circle") == 0 ) { 
                    
                    Circle *circle = initializeCircle();
                    
                    do {

                        strcpy(circle->units, unitCheck((char *) attribute->children->content));

                        if ( strcmp( (char *) attribute->name, "cx") == 0 ) {
                            circle->cx = atof( (char *) attribute->children->content);

                        } else if ( strcmp( (char *) attribute->name, "cy") == 0 ) {
                            circle->cy = atof( (char *) attribute->children->content);

                        } else if ( strcmp( (char *) attribute->name, "r") == 0 ) {
                            circle->r = atof( (char *) attribute->children->content);

                        } else {
                            Attribute *atty = initializeAttribute((char *) attribute->name, (char *) (attribute->children)->content);

                            insertBack( circle->otherAttributes, atty);
                        }
                    
                    } while ( (attribute = attribute->next )); 

                    insertBack(g->circles, circle);

                } else if ( strcmp( (char *) cur_node->name, "path") == 0 ) {

                    Path *path;

                    do {    //Need to loop once first to get the data attribute first. 

                        if ( strcmp( (char *) attribute->name, "d") == 0 ) {
                            path = initializePath( (char *) attribute->children->content);
                        }
                    
                    } while ( path == NULL);

                    attribute = cur_node->properties;
                    
                    do {    //Loop again, collecting all none data attributes as 'otherAttributes' 

                        if ( strcmp( (char *) attribute->name, "d") == 0 ) {
                            continue;

                        } else {
                            Attribute *atty = initializeAttribute((char *) attribute->name, (char *) (attribute->children)->content);

                            insertBack( path->otherAttributes, atty);
                        }
                    
                    } while ( (attribute = attribute->next) ); 

                    insertBack(g->paths, path);
                }          
            }
        }
        groupGetXmlInformation(cur_node->children, g);         //->Might cause errors, Im assuming that the group ends in rectangles/paths/circles, or another group with could call itself.
    }

    return g;
}

//gets the units from a string
char* unitCheck(char *content) {
    
    if(strstr(content, "mm") != NULL) {
        return "mm";

    } else if (strstr(content, "cm") != NULL) {
        return "cm";

    } else if (strstr(content, "px") != NULL) {
        return "px";
    }

    return "";
}

/*  Helper function for generateGroup. Doesn't get attributes everyloop so that's why I made it. 
*   @param: The root xmlNode used for looping through the XML tree, The group everything is being added to.
*/
void groupGetXmlInformation(xmlNode *newRoot, Group *g) {
    xmlNode *cur_node = NULL;

    for (cur_node = newRoot; cur_node; cur_node = cur_node->next) {
        if (cur_node->type == XML_ELEMENT_NODE) {   //This gets all the XML nodes recursivly 
            
            if ( strcmp( (char *) cur_node->name, "g") == 0 ) {     //If a group tag is encountered
                Group *g2 = generateGroup(cur_node);

                insertBack(g->groups, g2); 
                continue;
            }

            if (cur_node->properties != NULL) {     //This gets the attibutes. All of them.
                xmlAttr *attribute = cur_node->properties;
                
                //If the element is a rectangle, circle, or path, it will initialize it, populate it with its attributes and add it to the SVG element
                if ( strcmp( (char *) cur_node->name, "rectangle") == 0 ) { 

                    Rectangle *rect = initializeRectangle();
                    strcpy(rect->units, "");
                    
                    do {

                        if ( strcmp( (char *) attribute->name, "x") == 0 ) {
                            rect->x = atof( (char *) attribute->children->content);

                        } else if ( strcmp( (char *) attribute->name, "y") == 0 ) {
                            rect->x = atof( (char *) attribute->children->content);

                        } else if ( strcmp( (char *) attribute->name, "width") == 0 ) {
                            rect->x = atof( (char *) attribute->children->content);

                        } else if ( strcmp( (char *) attribute->name, "height") == 0 ) {
                            rect->x = atof( (char *) attribute->children->content);

                        } else {
                            Attribute *atty = initializeAttribute((char *) attribute->name, (char *) (attribute->children)->content);

                            insertBack( rect->otherAttributes, atty);
                        }
                    
                    } while ( (attribute = attribute->next) ); 

                    insertBack(g->rectangles, rect);

                } else if ( strcmp( (char *) cur_node->name, "circle") == 0 ) { 
                    
                    Circle *circle = initializeCircle();
                    
                    do {

                        if ( strcmp( (char *) attribute->name, "cx") == 0 ) {
                            circle->cx = atof( (char *) attribute->children->content);

                        } else if ( strcmp( (char *) attribute->name, "cy") == 0 ) {
                            circle->cy = atof( (char *) attribute->children->content);

                        } else if ( strcmp( (char *) attribute->name, "r") == 0 ) {
                            circle->r = atof( (char *) attribute->children->content);

                        } else {
                            Attribute *atty = initializeAttribute((char *) attribute->name, (char *) (attribute->children)->content);

                            insertBack( circle->otherAttributes, atty);
                        }
                    
                    } while ( (attribute = attribute->next) );

                    insertBack(g->circles, circle);  

                } else if ( strcmp( (char *) cur_node->name, "path") == 0 ) {

                    Path *path;

                    do {    //Need to loop once first to get the data attribute first. 

                        if ( strcmp( (char *) attribute->name, "d") == 0 ) {
                            path = initializePath( (char *) attribute->children->content);
                        }
                    
                    } while ( path == NULL);

                    attribute = cur_node->properties;
                    
                    do {    //Loop again, collecting all none data attributes as 'otherAttributes' 

                        if ( strcmp( (char *) attribute->name, "d") == 0 ) {
                            continue;

                        } else {
                            Attribute *atty = initializeAttribute((char *) attribute->name, (char *) (attribute->children)->content);

                            insertBack( path->otherAttributes, atty);
                        }
                    
                    } while ( (attribute = attribute->next) ); 

                    insertBack(g->paths, path);
                }          
            }
        }

        groupGetXmlInformation(cur_node->children, g);
    }
}

/*  returns a string that has a desc of every element in the SVG image. 
*   @Param the SVG image that is being is having it's information being printed out of.
*   @return the string of all the information about the image.
*/
char* SVGimageToString(SVGimage* img) {
    if (img == NULL) return NULL;

    char *text, *help;
    int size = 0;

    //Introduction: Namespace, title, and desk
    size += strlen("\nSVG image,\nNamespace = \ntitle = \ndescription = ");
    size += strlen(img->namespace) + strlen(img->title) + strlen(img->description);
    size += strlen("\n\nRectangles:\n\nCircles:\n\nPaths:\n\nGroups:\n\nOtherAttributes:\n");

    //rects
    help = toString(img->rectangles);
    size += strlen(help);
    free(help);

    //circles
    help = toString(img->circles);
    size += strlen(help);
    free(help);

    //paths
    help = toString(img->paths);
    size += strlen(help);
    free(help);
    
    //groups
    help = toString(img->groups);
    size += strlen(help);
    free(help);

    //otherAttributes
    help = toString(img->otherAttributes);
    size += strlen(help);
    free(help);

    text = malloc(sizeof(char) * size);
    
    strcpy(text, "\nSVG image,\nNamespace = ");
    strcat(text, img->namespace);
    strcat(text, "\ntitle = ");
    strcat(text, img->title);
    strcat(text, "\ndescription = ");
    strcat(text, img->description);

    //rects
    help = toString(img->rectangles);
    strcat(text, "\n\nRectangles:");
    strcat(text, help);
    free(help);

    //circles
    help = toString(img->circles);
    strcat(text, "\n\nCircles:");
    strcat(text, help);
    free(help);

    //paths
    help = toString(img->paths);
    strcat(text, "\n\nPaths:");
    strcat(text, help);
    free(help);
    
    //groups
    help = toString(img->groups);
    strcat(text, "\n\nGroups:");
    strcat(text, help);
    free(help);

    //otherAttributes
    help = toString(img->otherAttributes);
    strcat(text, "\n\nOtherAttributes:");
    strcat(text, help);
    free(help);
    
    return text;
}

/*  This deletes an SVG image.
*   @Param The image that will be deleted.
*/
void deleteSVGimage(SVGimage* img) {

    if (img == NULL) return;

    freeList(img->rectangles);
    freeList(img->circles);
    freeList(img->paths);
    freeList(img->groups);
    freeList(img->otherAttributes);

    free(img);

}
/*------------------- Module 2 Functions (their helpers are at the bottom) -------------------*/


// Function that returns a list of all rectangles in the image.  
List* getRects(SVGimage* img) {
    if (img == NULL) return NULL;

    int rectListLength = getLength(img->rectangles);
    int groupListLength = getLength(img->groups);
    
    List *newRectList = initializeList( &rectangleToString, &universalNoDelete, &compareRectangles);
    ListIterator iter = createIterator(img->rectangles);

    //Loops through the entire SVG rectangle list and gets all the rectangles.
    for (int i = 0; i < rectListLength; i++) {  
        Rectangle *rect = (Rectangle *) nextElement(&iter);

        insertBack(newRectList, rect);
    }

    //This loops through all the groups in the SVG image, finds any lists of rectangles and gets the rectangles.
    ListIterator svgGroupIter = createIterator(img->groups);

    for (int i = 0; i < groupListLength; i++) {   
        Group *g = (Group *) nextElement(&svgGroupIter); 
        
        //This gets called for every group in the svg element.
        getRectsFromGroup(g, newRectList);
    }

    return newRectList;    
}

// Function that returns a list of all circles in the image.  
List* getCircles(SVGimage* img) {
    if (img == NULL) return NULL;
    
    int circleListLength = getLength(img->circles);
    int groupListLength = getLength(img->groups);
    
    List *newCircleList = initializeList( &circleToString, &universalNoDelete, &compareCircles);
    ListIterator iter = createIterator(img->circles);

    //Loops through the entire SVG circle list and gets all the circles.
    for (int i = 0; i < circleListLength; i++) {    
        Circle *circle = (Circle *) nextElement(&iter);

        insertBack(newCircleList, circle);
    }

    //This loops through all the groups in the SVG image, finds any lists of rectangles and gets the rectangles.
    ListIterator svgGroupIter = createIterator(img->groups);
    for (int i = 0; i < groupListLength; i++) {    
        Group *g = (Group *) nextElement(&svgGroupIter); 
        
        //This gets called for every group in the svg element.
        getCirclesFromGroup(g, newCircleList);
    }

    return newCircleList; 

}

// Function that returns a list of all groups in the image.  
List* getGroups(SVGimage* img) {
    if (img == NULL) return NULL;
    
    List *newGroupList = initializeList( &groupToString, &universalNoDelete, &compareGroups);

    //This loops through all the groups in the SVG image, finds any lists of rectangles and gets the rectangles.
    ListIterator svgGroupIter = createIterator(img->groups);
    for (int i = 0; i < getLength(img->groups); i++) {    
        Group *g = (Group *) nextElement(&svgGroupIter);

        insertBack(newGroupList, g);
        
        //This gets called for every group in the svg element.
        getGroupsFromGroup(g, newGroupList);
    }

    return newGroupList; 

}

// Function that returns a list of all paths in the image.  
List* getPaths(SVGimage* img) {
    if (img == NULL) return NULL;

    int pathListLength = getLength(img->paths);
    int groupListLength = getLength(img->groups);
    
    List *newPathList = initializeList( &pathToString, &universalNoDelete, &comparePaths);
    ListIterator iter = createIterator(img->paths);

    //Loops through the entire SVG path list and gets all the path.
    for (int i = 0; i < pathListLength; i++) {
        Path *path = (Path *) nextElement(&iter);

        insertBack(newPathList, path);
    }

    //This loops through all the groups in the SVG image, finds any lists of rectangles and gets the rectangles.
    ListIterator svgGroupIter = createIterator(img->groups);
    for (int i = 0; i < groupListLength; i++) {    
        Group *g = (Group *) nextElement(&svgGroupIter); 
        
        //This gets called for every group in the svg element.
        getPathsFromGroup(g, newPathList);
    }

    return newPathList; 

}

// Function that returns the number of all rectangles with the specified area
int numRectsWithArea(SVGimage* img, float area) {
    if (img == NULL) return 0;

    List *rectList = getRects(img);
    int length = getLength(rectList);
    int totalCount = 0;
    ListIterator iter = createIterator(rectList);

    for (int i = 0; i < length; i++) {

        Rectangle *rect = (Rectangle *) nextElement(&iter); 

        if ( ceil(rect->width * rect->height) == ceil(area) ) totalCount++;
    }

    freeList(rectList);
    return totalCount;
}
// Function that returns the number of all circles with the specified area
int numCirclesWithArea(SVGimage* img, float area) {
    if (img == NULL) return 0;

    List *circleList = getCircles(img);
    int length = getLength(circleList);
    int totalCount = 0;
    ListIterator iter = createIterator(circleList);

    for (int i = 0; i < length; i++) {

        Circle *circle = (Circle *) nextElement(&iter); 

        if ( ceil(circle->r * circle->r * 3.1415) == ceil(area) ) totalCount++;
    }

    freeList(circleList);
    return totalCount;
}
// Function that returns the number of all paths with the specified data - i.e. Path.data field
int numPathsWithdata(SVGimage* img, char* data) {
    if (img == NULL) return 0;
    
    List *pathList = getPaths(img);
    int totalCount = 0;
    ListIterator iter = createIterator(pathList);    

    for (int i = 0; i < getLength(pathList); i++) {

        Path *path = (Path *) nextElement(&iter); 
        if ( strcmp(path->data, data) == 0) totalCount++;
    }

    freeList(pathList);
    return totalCount;
}
// Function that returns the number of all groups with the specified length - see A1 Module 2 for details
int numGroupsWithLen(SVGimage* img, int len) {
    if (img == NULL) return 0;
    
    int totalCount = 0;
    int comparitor;

    List *groups = getGroups(img);
    int numGroups = getLength(groups);

    ListIterator iter = createIterator(groups);

    for (int i = 0; i < numGroups; i++) {
        Group *gSub = nextElement(&iter);
        
        comparitor = getSizeOfGroup(gSub);

        if (comparitor == len) totalCount++;

        totalCount += getGroupsFromParentGroup(gSub, len);
    }

    freeList(groups);
    return totalCount;
}

/*  Function that returns the total number of Attribute structs in the SVGimage - i.e. the number of Attributes
    contained in all otherAttributes lists in the structs making up the SVGimage
    *@pre SVGimgage  exists, is not null, and has not been freed.  
    *@post SVGimage has not been modified in any way
    *@return the total length of all attribute structs in the SVGimage
    *@param obj - a pointer to an SVG struct
*/
int numAttr(SVGimage* img) {
    if (img == NULL) return 0;
    
    int totalCount = 0;

    //SVG attributes
    totalCount += getLength(img->otherAttributes);

    //Rectangles;
    totalCount += getAttributeCountFromRectangleList(img->rectangles);

    //Circles
    totalCount += getAttributeCountFromCircleList(img->circles);

    //Paths
    totalCount += getAttributeCountFromPathList(img->paths);

    //Groups
    totalCount += getAttributeCountFromGroupList(img->groups);

    return totalCount;
}

/*------------------- ALL the struct initialization functions helper functions -------------------*/

/* "One comment to rule them all" -> This stands for all of the initialization functions. Initializes an object of what ever is specified.
*   This means everything is malloced, lists are initialized correctly, but no data is actually in the pointers.
*   
*   @Param If theres a string that is passed into one of the functions (Attribute/path), you pass the string in as a parameter.
*/

//See above for explaination
SVGimage* initializeSvgImage() {
    SVGimage *image = malloc(sizeof(SVGimage));
    
    strcpy(image->namespace, "");
    strcpy(image->title, "");
    strcpy(image->description, "");

    image->rectangles = initializeList( &rectangleToString, &deleteRectangle, &compareRectangles);
    image->circles = initializeList( &circleToString, &deleteCircle, &compareCircles);
    image->paths = initializeList( &pathToString, &deletePath, &comparePaths);
    image->groups = initializeList( &groupToString, &deleteGroup, &compareGroups);
    image->otherAttributes = initializeList(  &attributeToString, &deleteAttribute, &compareAttributes);

    return image;
}

//See above for explaination
Group* initializeGroup() {
    Group *g = malloc( sizeof(Group));

 
    g->rectangles = initializeList(  &rectangleToString, &deleteRectangle, &compareRectangles);
    g->circles = initializeList(  &circleToString, &deleteCircle, &compareCircles);
    g->paths = initializeList(  &pathToString, &deletePath, &comparePaths);
    g->groups = initializeList(  &groupToString, &deleteGroup, &compareGroups);
    g->otherAttributes = initializeList(  &attributeToString, &deleteAttribute, &compareAttributes);
    
    return g;
}

//See above for explaination
Rectangle* initializeRectangle() {
    Rectangle *rect = malloc( sizeof(Rectangle));

    rect->otherAttributes = initializeList( &attributeToString, &deleteAttribute, &compareAttributes);

    return rect;
}

//See above for explaination
Circle* initializeCircle() {
    Circle *circle = malloc( sizeof(Circle));
    
    circle->otherAttributes = initializeList( &attributeToString, &deleteAttribute, &compareAttributes);


    return circle;
}

//See above for explaination
Path* initializePath(char *data) {
    Path *path = malloc( sizeof(Path));

    path->data = malloc( sizeof(char) * strlen(data)  + 1);
    strcpy(path->data, data);
    strcat(path->data, "\0");


    path->otherAttributes = initializeList( &attributeToString, &deleteAttribute, &compareAttributes);


    return path;
}

//See above for explaination
Attribute* initializeAttribute(char *name, char *value) {
    Attribute *atty = malloc( sizeof(Attribute));

    atty->name = malloc( sizeof(char) * strlen(name) + 1);
    atty->value = malloc( sizeof(char) * strlen(value) + 1);

    strcpy(atty->name, name);
    strcpy(atty->value, value);

    strcat(atty->name, "\0");
    strcat(atty->value, "\0");
    
    return atty;
}


/*------------------- ALL the Linked List helper functions -------------------*/
// *** ATTRIBUTES ***
char* attributeToString( void* data) {

    Attribute *atty = (Attribute *) data;
    char *returnVal;

    returnVal = malloc( sizeof(char) * (strlen(atty->name) + strlen(atty->value) + strlen(": ") + 1));   // +1 for the ': ' and +1 for the '\0'
    strcpy(returnVal, atty->name);
    strcat(returnVal, ": ");
    strcat(returnVal, atty->value);
    strcat(returnVal, "\0");

    return returnVal;
}

void deleteAttribute( void* data) {
    Attribute *atty = (Attribute *) data;

    free(atty->name);
    free(atty->value);
    free(atty);
}

int compareAttributes(const void *first, const void *second) {   // <0 for first bigger, 0 on equal, >0 for second, NULL when they're different elements.
    
    if (first == NULL) {
        return -1;
        
    } else if (second == NULL) {
        return 1;
    }

    Attribute *a = (Attribute *) first;
    Attribute *b = (Attribute *) second;

    if (strcmp(a->name, b->name) == 0) {
        return strcmp(a->value, b->value);

    }

    return 0;
}


// *** RECTANGLE ***
char* rectangleToString(void* data) {
    
    Rectangle *rect = (Rectangle *) data;
    char x[15], y[15], width[15], height[15], *returnVal;

    returnVal = malloc(sizeof(char) * 5000);

    //x value
    snprintf(x, NUMFLOATINGPOINTS, "%f", rect->x);
    //returnVal = malloc( sizeof(char) * (strlen("X: ") + 10));
    strcpy(returnVal, "X: ");
    strcat(returnVal, x);

    //y value
    snprintf(y, NUMFLOATINGPOINTS, "%f", rect->y);
    //returnVal = realloc(returnVal, sizeof(char) * (strlen(", Y: ") + 10 + strlen(returnVal)));
    strcat(returnVal, ", Y: ");
    strcat(returnVal, y);

    //width value
    snprintf(width, NUMFLOATINGPOINTS, "%f", rect->width);
    //returnVal = realloc(returnVal, sizeof(char) * (strlen(", width: ") + 10  + strlen(returnVal)));
    strcat(returnVal, ", width: ");
    strcat(returnVal, width);

    //height value
    snprintf(height, NUMFLOATINGPOINTS, "%f", rect->height);
    //returnVal = realloc(returnVal, sizeof(char) * (strlen(", height: ") + 10  + strlen(returnVal)));
    strcat(returnVal, ", height: ");
    strcat(returnVal, height);

    //Units value
    if (strlen(rect->units) != 0) {
        
        //returnVal = realloc(returnVal, sizeof(char) * (strlen(", Units: ") + strlen(rect->units) + strlen(returnVal)));
        strcat(returnVal, ", Units: ");
        strcat(returnVal, rect->units);
     }

    //Attributes value
    //returnVal = realloc(returnVal, sizeof(char) * (strlen( toString(rect->otherAttributes)) + strlen(returnVal)));
    char *temp = toString(rect->otherAttributes);

    strcat( returnVal, ", Attributes: ");
    strcat( returnVal, temp);
    free(temp);

    char *actualReturnVal;
    actualReturnVal = malloc(sizeof(char) * strlen(returnVal) + 1);

    strcpy(actualReturnVal, returnVal);
    strcat(actualReturnVal, "\0");
    free(returnVal);
        
    return actualReturnVal;
}

void deleteRectangle(void *data) {
    Rectangle *rect = (Rectangle *) data;

    freeList(rect->otherAttributes);    
    free(rect);
}

int compareRectangles(const void* first, const void* second) {   //1 for same, 0 for different.
    
    if (first == NULL) {
        return -1;
        
    } else if (second == NULL) {
        return 1;
    }

    Rectangle *a = (Rectangle *) first;
    Rectangle *b = (Rectangle *) second;
    
    //Check all the values first.
    if (a->x != b->x) {
        return 0;

    } else if (a->y != b->y) {
        return 0;

    } else if (a->width != b->width) {
        return 0;

    } else if (a->height != b->height) {
        return 0;
    
    } else if ( strcmp(a->units, b->units) != 0 ) {
        return 0;
    
    } else if ( strcmp( toString(a->otherAttributes), toString(b->otherAttributes) ) != 0) {
        return 0;
    }
    
    return 1;
    
}


// *** CIRCLE ***
char* circleToString(void *data) {

    Circle *circle = (Circle *) data;
    char cx[15], cy[15], r[15], *returnVal;

    returnVal = malloc(sizeof(char) * 5000);  //Endline char

    //cx value
    snprintf(cx, NUMFLOATINGPOINTS, "%f", circle->cx);
    //returnVal = realloc(returnVal, sizeof("CX: ") + sizeof(cx)  + sizeof(returnVal) );
    strcpy(returnVal, "CX: ");
    strcat(returnVal, cx);

    //cy value
    snprintf(cy, NUMFLOATINGPOINTS, "%f", circle->cy);
    //returnVal = realloc(returnVal, sizeof(", CY: ") + sizeof(cy) + sizeof(returnVal) );
    strcat(returnVal, ", CY: ");
    strcat(returnVal, cy);

    //r value
    snprintf(r, NUMFLOATINGPOINTS, "%f", circle->r);
    //returnVal = realloc(returnVal, sizeof(", R: ") + sizeof(r) + sizeof(returnVal) );
    strcat(returnVal, ", r: ");
    strcat(returnVal, r);

    //Units value
    if (strlen(circle->units) != 0) {
        
        //returnVal = realloc(returnVal, sizeof(", Units: ") + sizeof(circle->units) + sizeof(returnVal) );
        strcat(returnVal, ", Units: ");
        strcat(returnVal, circle->units);
     }

    //Attributes value
    //returnVal = realloc(returnVal, sizeof(char) * strlen( toString(circle->otherAttributes) )+ sizeof(returnVal) );

    char *temp = toString(circle->otherAttributes);
    strcat( returnVal, temp );
    free(temp);

    char *actualReturnVal = malloc(sizeof(char) * strlen(returnVal) + 1);
    strcpy(actualReturnVal, returnVal);
    strcat(actualReturnVal, "\0");
    free(returnVal);

    return actualReturnVal;
}

void deleteCircle(void *data) {
    Circle *circle = (Circle *) data;

    freeList(circle->otherAttributes);   
    free(circle); 
}

int compareCircles(const void* first, const void* second) {   //1 for same, 0 for different.
    
    if (first == NULL) {
        return -1;
        
    } else if (second == NULL) {
        return 1;
    }

    Circle *a = (Circle *) first;
    Circle *b = (Circle *) second;
   
    if (a->cx != b->cx) {
        return 0;

    } else if (a->cy != b->cy) {
        return 0;

    } else if (a->r != b->r) {
        return 0;

    } else if ( strcmp(a->units, b->units) != 0 ) {
        return 0;
    
    } else if ( strcmp( toString(a->otherAttributes), toString(b->otherAttributes)) != 0) {
        return 0;
    }
    
    return 1;
}


// *** PATHS ***
char* pathToString(void *data) {
 
    Path *path = (Path *) data;
    char *returnVal = malloc(sizeof(char) * 5000);

    char *intermediateValue = toString(path->otherAttributes);

    strcpy(returnVal, "Data: ");
    strcat(returnVal, path->data);
    strcat(returnVal, ", Attributes: ");
    strcat(returnVal, intermediateValue);

    free(intermediateValue);

    char *actualReturn = malloc(sizeof(char) * strlen(returnVal) + 1);
    strcpy(actualReturn, returnVal);
    strcat(actualReturn, "\0");

    free(returnVal);

    return actualReturn;    
}

void deletePath(void *data) {
    Path *path = (Path *) data;

    free(path->data);
    freeList(path->otherAttributes); 
    free(path);
}

int comparePaths(const void* first, const void* second) {    //1 for same, 0 for different.
    
    if (first == NULL) {
        return -1;
        
    } else if (second == NULL) {
        return 1;
    }

    Path *a = (Path *) first;
    Path *b = (Path *) second;

    if ( strcmp(a->data, b->data) != 0 ) {
        return 0;
    
    } else if ( strcmp( toString(a->otherAttributes), toString(b->otherAttributes)) != 0) {
        return 0;
    }
    
    return 1;
}


// *** GROUP ***
char* groupToString(void *data) {

    Group *group = (Group *) data;

    int totalLength;
    char *returnVal;

    char *groupRects = toString(group->rectangles);
    char *groupCircles = toString(group->circles);
    char *groupPaths = toString(group->paths);
    char *groupGroups = toString(group->groups);
    char *groupAttributes = toString(group->otherAttributes);

    totalLength = strlen( groupRects ) + strlen( groupCircles ) + strlen( groupPaths )
                + strlen( groupGroups ) + strlen( groupAttributes );

    totalLength += strlen("Rectangles: ") + strlen(" | Circles: ") + strlen(" | Paths: ") + strlen(" | Groups: ") + 
                    strlen(" | Attributes: ") + 1; //Plus one for the null terminator

    returnVal = malloc( sizeof(char) * totalLength);

    strcpy(returnVal, "Rectangles: ");
    strcat(returnVal, groupRects);
    strcat(returnVal, " | Circles: ");
    strcat(returnVal, groupCircles);
    strcat(returnVal, " | Paths: ");
    strcat(returnVal, groupPaths);
    strcat(returnVal, " | Groups: ");
    strcat(returnVal, groupGroups);
    strcat(returnVal, " | Attributes: ");
    strcat(returnVal, groupAttributes);
    strcat(returnVal, "\0");

    free(groupRects);
    free(groupCircles);
    free(groupPaths);
    free(groupGroups);
    free(groupAttributes);

    return returnVal;
}

void deleteGroup(void *data) {

    Group *group = (Group *) data;

    freeList(group->rectangles);
    freeList(group->circles);
    freeList(group->paths);
    freeList(group->groups);
    freeList(group->otherAttributes);
    free(group);
}

int compareGroups(const void* first, const void* second) {   //1 for same, 0 for different.
    
    if (first == NULL) {
        return -1;
        
    } else if (second == NULL) {
        return 1;
    }

    Group *a = (Group *) first;
    Group *b = (Group *) second;

    if ( getLength(a->rectangles) != getLength(a->rectangles)) {    //Compar the lengths of all the LL first, faster compute times this way.
        return 0;

    } else if ( getLength(a->circles) != getLength(a->circles)) {
        return 0;

    } else if ( getLength(a->paths) != getLength(a->paths)) {
        return 0;

    } else if ( getLength(a->groups) != getLength(a->groups)) {
        return 0;

    } else if ( getLength(a->otherAttributes) != getLength(a->otherAttributes)) {   //Then compar all the actual elements of the LL using their strings.
        return 0;

    } else if ( strcmp(toString(a->rectangles), toString(b->rectangles) ) != 0 ) {
        return 0;
        
    } else if ( strcmp(toString(a->circles), toString(b->circles) ) != 0 ) {
        return 0;
        
    } else if ( strcmp(toString(a->paths), toString(b->paths) ) != 0 ) {
        return 0;
        
    } else if ( strcmp(toString(a->groups), toString(b->groups) ) != 0 ) {
        return 0;
        
    } else if ( strcmp(toString(a->otherAttributes), toString(b->otherAttributes) ) != 0 ) {
        return 0;
    }

    return 1;
}

// For module 2 nothing should be deleted when a list frees something so this is inputted instead of the correct delete function
void universalNoDelete(void *data) {
    return;
}

/*  This is a recursive algorithm that gets all the rectangles from a group. Then calls itself on each of the subgroups in the group.
*   @Param  the group to be disected, the list of the rectangles.
*/
void getRectsFromGroup(Group *g, List *newRectList) {
    
    //For the rectangles.
    int rectListLength = getLength(g->rectangles);
    ListIterator iter = createIterator(g->rectangles);

    for (int i = 0; i < rectListLength; i++) {
        Rectangle *rect = (Rectangle *) nextElement(&iter);

        insertBack(newRectList, rect);
    }

    //Now the subgroups

    int groupListLength = getLength(g->groups);
    ListIterator svgGroupIter = createIterator(g->groups);
    for (int i = 0; i < groupListLength; i++) {    
        Group *gSub = (Group *) nextElement(&svgGroupIter); 
        
        //This gets called for every group in the svg element.
        getRectsFromGroup(gSub, newRectList);
    }
}

/*  This is a recursive algorithm that gets all the circles from a group. Then calls itself on each of the subgroups in the group.
*   @Param  the group to be disected, the list of the circles.
*/
void getCirclesFromGroup(Group *g, List *newCircleList) {
    
    //For the circles.
    int circleListLength = getLength(g->circles);
    ListIterator iter = createIterator(g->circles);

    for (int i = 0; i < circleListLength; i++) {    
        Circle *circle = (Circle *) nextElement(&iter);

        insertBack(newCircleList, circle);
    }

    //Now the subgroups

    int groupListLength = getLength(g->groups);
    ListIterator svgGroupIter = createIterator(g->groups);
    for (int i = 0; i < groupListLength; i++) {    
        Group *gSub = (Group *) nextElement(&svgGroupIter); 
        
        //This gets called for every group in the svg element.
        getCirclesFromGroup(gSub, newCircleList);
    }
}

/*  This is a recursive algorithm that gets all the groups from a group. Then calls itself on each of the subgroups in the group.
*   @Param  the group to be disected, the list of the groups.
*/
void getGroupsFromGroup(Group *g, List *newGroupList) {
    
    int groupListLength = getLength(g->groups);
    ListIterator iter = createIterator(g->groups);

    for (int i = 0; i < groupListLength; i++) {    
        Group *gSub = (Group *) nextElement(&iter); 

        insertBack(newGroupList, gSub);
        
        //This gets called for every group in the svg element.
        getGroupsFromGroup(gSub, newGroupList);
    }
}

/*  This is a recursive algorithm that gets all the paths from a group. Then calls itself on each of the subgroups in the group.
*   @Param  the group to be disected, the list of the paths.
*/
void getPathsFromGroup(Group *g, List *newPathList) {
    
    //For the path.
    int pathListLength = getLength(g->paths);
    ListIterator iter = createIterator(g->paths);

    for (int i = 0; i < pathListLength; i++) {    
        Path *path = (Path *) nextElement(&iter);

        insertBack(newPathList, path);
    }

    //Now the subgroups

    int groupListLength = getLength(g->groups);
    ListIterator groupIter = createIterator(g->groups);
    for (int i = 0; i < groupListLength; i++) {    
        Group *gSub = (Group *) nextElement(&groupIter); 
        
        //This gets called for every group in the svg element.
        getPathsFromGroup(gSub, newPathList);
    }
}

/*  Help function for 'numGroupsWithLen'. This recursively goes through all the groups (Depth-first) and finds all groups with that length
    adding them all up and returning the total count. 
*   @Param the group being dissected. The length we are comparing against the length of the group list.
*   @Return the total number of length(g->groups) we found for every group in the svg image.
*/
int getGroupsFromParentGroup(Group *g, int len) {
    int comparitor, totalCount = 0;
    int childrenCount = getLength(g->groups);
    ListIterator iter = createIterator(g->groups);

    for (int i = 0; i < childrenCount; i++) {
        Group *gSub = nextElement(&iter);

        comparitor = getSizeOfGroup(gSub);

        if (comparitor == len) totalCount++;

        totalCount += getGroupsFromParentGroup(gSub, len);
    }
    return totalCount;
}

/*------------------- Helper functions for 'numAtter', gets all the attributes for each list -------------------*/
//Rectangles;
int getAttributeCountFromRectangleList(List *rectangleList) {
    int totalCount = 0; 
    ListIterator iter = createIterator(rectangleList);

    for (int i = 0; i < getLength(rectangleList); i++) {
        Rectangle *rect = nextElement(&iter);

        totalCount += getLength(rect->otherAttributes);
    }
    return totalCount;
}

//Circles
int getAttributeCountFromCircleList(List *circleList) {
    int totalCount = 0; 
    ListIterator iter = createIterator(circleList);

    for (int i = 0; i < getLength(circleList); i++) {
        Circle *circle = nextElement(&iter);

        totalCount += getLength(circle->otherAttributes);
    }
    return totalCount;
}

//Paths
int getAttributeCountFromPathList(List *pathList) {
    int totalCount = 0; 
    ListIterator iter = createIterator(pathList);

    for (int i = 0; i < getLength(pathList); i++) {
        Path *path = nextElement(&iter);

        totalCount += getLength(path->otherAttributes);
    }
    return totalCount;
}

//Groups -> This one is a little different in that it calls the above functions and calls itself recursively.
int getAttributeCountFromGroupList(List *groupsList) {
    int totalCount = 0;

    ListIterator iter = createIterator(groupsList);

    for (int i = 0; i < getLength(groupsList); i++) {
        Group *subgroup = nextElement(&iter);

        totalCount += getAttributesFromGroupAndItsShapes(subgroup);

        totalCount += getAttributeCountFromGroupList(subgroup->groups);
    }
    return totalCount;
}

/*  Helper for 'getAttributeCountFromGroupList' (above), calls all the other functions that get the attribute count from a list of shapes.
*   @Param the group whos shape lists that the attributes will be counted.
*   @Return the count of all attributes from that group and it's shape children.
*/
int getAttributesFromGroupAndItsShapes(Group *group) {
    int totalCount = 0;

    totalCount += getLength(group->otherAttributes);
    totalCount += getAttributeCountFromRectangleList(group->rectangles);
    totalCount += getAttributeCountFromCircleList(group->circles);
    totalCount += getAttributeCountFromPathList(group->paths);

    return totalCount;
}


int getSizeOfGroup(Group *gsub) {
    int length = 0;

    length += getLength(gsub->rectangles);
    length += getLength(gsub->circles);
    length += getLength(gsub->paths);
    length += getLength(gsub->groups);

    return length;
}